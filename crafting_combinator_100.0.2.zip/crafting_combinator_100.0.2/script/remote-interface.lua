remote.add_interface("crafting_combinator",
{
    get_migration_data = function()
        return global
    end,
})